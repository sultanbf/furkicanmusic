const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "..")));

/* ── Suno API proxy ─────────────────────────────
 * Frontend'in API key'ini görmesine gerek kalmadan
 * üçüncü parti Suno servislerine güvenli çağrı yapar.
 * Desteklenen sağlayıcılar: sunor, songapi, apiframe, gcui
 */
const PROVIDER = {
  sunoapi: {
    create: (base, key, body) => {
      const b = base.replace(/\/$/, "");
      const url = b.endsWith("/api/v1") ? `${b}/generate` : `${b}/api/v1/generate`;
      const lyrics = body.lyrics || (body.prompt && body.prompt.length > 500 ? body.prompt : "");
      const customMode = !!lyrics;
      return {
        url,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: {
          prompt: lyrics || body.prompt || "",
          style: customMode ? body.style : "",
          title: customMode ? (body.title || body.songTitle || "") : "",
          customMode,
          instrumental: !!body.instrumental,
          model: body.model || "V4_5",
          callBackUrl: body.callBackUrl || undefined,
        },
      };
    },
    taskId: (d) => d?.data?.taskId || d?.data?.id || d?.taskId,
    statusUrl: (base, id) => {
      const b = base.replace(/\/$/, "");
      return b.endsWith("/api/v1")
        ? `${b}/generate/record-info?taskId=${id}`
        : `${b}/api/v1/generate/record-info?taskId=${id}`;
    },
    parse: (d) => {
      const resp = d?.data?.response || d?.response || {};
      const arr = Array.isArray(resp.data) ? resp.data : resp.sunoData || [];
      const tracks = arr.map((t) => ({
        id: t.id,
        audio_url: t.audio_url || t.audioUrl,
        image_url: t.image_url || t.imageUrl,
        title: t.title,
        tags: t.tags,
        duration: t.duration,
      }));
      return {
        status: d?.data?.status || d?.status,
        errorMessage: d?.data?.errorMessage || d?.errorMessage || d?.data?.msg || d?.msg,
        tracks,
        audio_url: tracks[0]?.audio_url,
        image_url: tracks[0]?.image_url,
        title: tracks[0]?.title,
        tags: tracks[0]?.tags,
      };
    },
  },
  sunor: {
    create: (base, key, body) => ({
      url: `${base.replace(/\/$/, "")}/task`,
      headers: { "Content-Type": "application/json", "x-api-key": key },
      body: {
        model: "suno",
        task_type: "music",
        input: {
          gpt_description_prompt: body.prompt,
          make_instrumental: !!body.instrumental,
          title: body.title,
          tags: body.style,
          custom_mode: !!body.lyrics,
          model_version: body.model || undefined,
          vocal_gender: body.vocalGender === "kadin" ? "f" : body.vocalGender === "erkek" ? "m" : undefined,
        },
      },
    }),
    taskId: (d) => d?.data?.taskId || d?.data?.task_id || d?.data?.id || d?.taskId || d?.id,
    statusUrl: (base, id) => `${base.replace(/\/$/, "")}/task/${id}`,
    parse: (d) => d?.data || d,
  },
  songapi: {
    create: (base, key, body) => ({
      url: `${base.replace(/\/$/, "")}/generate`,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: {
        prompt: body.prompt,
        title: body.title,
        style: body.style,
        lyrics: body.lyrics || undefined,
        instrumental: !!body.instrumental,
        model: body.model || undefined,
      },
    }),
    taskId: (d) => d?.data?.id || d?.id,
    statusUrl: (base, id) => `${base.replace(/\/$/, "")}/generate/${id}`,
    parse: (d) => d?.data || d,
  },
  apiframe: {
    create: (base, key, body) => ({
      url: `${base.replace(/\/$/, "")}/music/generate`,
      headers: { "Content-Type": "application/json", "X-API-Key": key },
      body: {
        prompt: body.prompt,
        model: "suno",
        sunoParams: {
          custom_mode: !!body.lyrics,
          instrumental: !!body.instrumental,
          model_version: body.model || undefined,
          title: body.title,
          style: body.style,
        },
      },
    }),
    taskId: (d) => d?.id || d?.jobId,
    statusUrl: (base, id) => `${base.replace(/\/$/, "")}/jobs/${id}`,
    parse: (d) => d,
  },
  gcui: {
    create: (base, key, body) => ({
      url: `${base.replace(/\/$/, "")}/api/custom_generate`,
      headers: { "Content-Type": "application/json", ...(key ? { Cookie: key } : {}) },
      body: {
        prompt: body.lyrics || body.prompt,
        style: body.style,
        title: body.title,
        instrumental: !!body.instrumental,
        model: body.model || undefined,
      },
    }),
    taskId: (d) => (Array.isArray(d) ? d[0]?.id : d?.id),
    statusUrl: (base, id) => `${base.replace(/\/$/, "")}/api/get?ids=${id}`,
    parse: (d) => (Array.isArray(d) ? d[0] : d),
  },
};

app.post("/api/suno/create", async (req, res) => {
  try {
    const { apiType, apiKey, baseUrl, ...body } = req.body;
    const p = PROVIDER[apiType] || PROVIDER.sunor;
    if (!body.callBackUrl) {
      body.callBackUrl = `${req.protocol}://${req.get("host")}/api/suno/callback`;
    }
    const apiReq = p.create(baseUrl || process.env.SUNO_BASE_URL, apiKey || process.env.SUNO_API_KEY, body);

    const r = await fetch(apiReq.url, { method: "POST", headers: apiReq.headers, body: JSON.stringify(apiReq.body) });
    const json = await r.json().catch(() => ({}));
    if (!r.ok) {
      return res.status(r.status).json({ error: json.message || json.msg || `HTTP ${r.status}` });
    }

    if (json.code !== undefined && json.code !== 200) {
      console.error("[suno create] API hata yanıtı:", JSON.stringify(json).slice(0, 800));
      return res.status(400).json({
        error: json.msg || json.message || `API hatası (code: ${json.code})`,
        code: json.code,
      });
    }

    const taskId = p.taskId(json);
    if (!taskId) {
      console.error("[suno create] Görev ID çözümlenemedi, raw:", JSON.stringify(json).slice(0, 800));
      return res.status(502).json({ error: "Görev ID çözümlenemedi", raw: json });
    }

    res.json({ taskId, raw: json });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* sunoapi.org gibi servislerin bildirim gönderdiği uç — yalnızca 200 döner */
app.post("/api/suno/callback", (req, res) => {
  res.status(200).json({ status: "received" });
});

app.get("/api/suno/status", async (req, res) => {
  try {
    const { taskId, apiType, baseUrl } = req.query;
    const p = PROVIDER[apiType] || PROVIDER.sunor;
    const url = p.statusUrl(baseUrl || process.env.SUNO_BASE_URL, taskId);

    const headers = {};
    const key = req.query.apiKey || process.env.SUNO_API_KEY;
    if (key) {
      headers["x-api-key"] = key;
      headers.Authorization = `Bearer ${key}`;
      if (apiType === "gcui") headers.Cookie = key;
    }

    const r = await fetch(url, { headers });
    const json = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(r.status).json({ error: json.message || `HTTP ${r.status}` });
    res.json({ data: p.parse(json) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ── n8n webhook proxy ─────────────────────────
 * Tarayıcı CORS engelini aşmak için: istek önce bu sunucuya gelir (aynı
 * origin, CORS yok), sunucu n8n webhook'una bağlanır ve yanıtı (JSON veya
 * binary ses/video) olduğu gibi geri gönderir.
 */
app.post("/api/n8n", async (req, res) => {
  try {
    const { _webhookUrl, ...body } = req.body || {};
    const target = String(_webhookUrl || "").trim();
    if (!target) return res.status(400).json({ error: "_webhookUrl gerekli" });

    const r = await fetch(target, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      redirect: "follow",
    });

    res.status(r.status);
    const ct = r.headers.get("content-type") || "";
    if (ct) res.setHeader("Content-Type", ct);
    const buf = Buffer.from(await r.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(502).json({ error: "n8n proxy hatası: " + e.message });
  }
});

app.listen(PORT, () => {
  console.log(`AI Music Studio çalışıyor: http://localhost:${PORT}`);
});
